DROP TABLE IF EXISTS evaluations;
DROP TABLE IF EXISTS projects;
DROP TABLE IF EXISTS interns;

CREATE TABLE interns (
    intern_id INT PRIMARY KEY,
    first_name VARCHAR(100),
    last_name VARCHAR(100),
    email VARCHAR(150),
    phone VARCHAR(50),
    degree VARCHAR(100),
    university VARCHAR(150),
    year_graduation INT
);

CREATE TABLE projects (
    project_id INT PRIMARY KEY,
    title VARCHAR(200),
    description TEXT,
    tech_stack VARCHAR(200),
    start_date DATE,
    end_date DATE,
    owner_id INT,
    CONSTRAINT fk_project_owner FOREIGN KEY(owner_id) REFERENCES interns(intern_id) ON DELETE SET NULL
);

CREATE TABLE evaluations (
    evaluation_id INT PRIMARY KEY,
    intern_id INT,
    project_id INT,
    score NUMERIC(6,2),
    feedback TEXT,
    evaluator VARCHAR(150),
    CONSTRAINT fk_eval_intern FOREIGN KEY(intern_id) REFERENCES interns(intern_id) ON DELETE CASCADE,
    CONSTRAINT fk_eval_project FOREIGN KEY(project_id) REFERENCES projects(project_id) ON DELETE CASCADE
);

CREATE INDEX idx_projects_owner ON projects(owner_id);
CREATE INDEX idx_evals_intern ON evaluations(intern_id);
CREATE INDEX idx_evals_project ON evaluations(project_id);
