import { Link, useLocation } from "react-router-dom";
import "./Navbar.css";

export default function Navbar() {
  const { pathname } = useLocation();

  return (
    <nav className="navbar">
      <div className="nav-logo">Internship Portal</div>

      <ul className="nav-links">
        <li className={pathname === "/" ? "active" : ""}>
          <Link to="/">Intern Details</Link>
        </li>
        <li className={pathname === "/projects" ? "active" : ""}>
          <Link to="/projects">Project Details</Link>
        </li>
        <li className={pathname === "/evaluation" ? "active" : ""}>
          <Link to="/evaluation">Evaluation Criteria</Link>
        </li>
      </ul>
    </nav>
  );
}
