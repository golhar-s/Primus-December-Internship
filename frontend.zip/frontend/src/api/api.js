import axios from "axios";

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || "http://localhost:5172";

export const api = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    "Content-Type": "application/json",
  },
});

// ------------------- INTERN API -------------------

// Get all interns
export const getInterns = () => api.get("/api/interns").then(res => res.data);

// Get intern by ID
export const getInternById = (id) => api.get(`/api/interns/${id}`).then(res => res.data);

// Create new intern
export const createIntern = (intern) => api.post("/api/interns", intern).then(res => res.data);

// Update intern
export const updateIntern = (id, intern) => api.put(`/api/interns/${id}`, intern).then(res => res.data);

// Delete intern
export const deleteIntern = (id) => api.delete(`/api/interns/${id}`).then(res => res.data);

// ------------------- PROJECT API -------------------

// Get all projects
export const getProjects = () => api.get("/api/projects").then(res => res.data);

// Get project by ID
export const getProjectById = (id) => api.get(`/api/projects/${id}`).then(res => res.data);

// Create new project
export const createProject = (project) => api.post("/api/projects", project).then(res => res.data);

// Update project
export const updateProject = (id, project) => api.put(`/api/projects/${id}`, project).then(res => res.data);

// Delete project
export const deleteProject = (id) => api.delete(`/api/projects/${id}`).then(res => res.data);

// ------------------- EVALUATION API -------------------

// Get all evaluations
export const getEvaluations = () => api.get("/api/evaluations").then(res => res.data);

// Get evaluation by ID
export const getEvaluationById = (id) => api.get(`/api/evaluations/${id}`).then(res => res.data);

// Create new evaluation
export const createEvaluation = (evaluation) => api.post("/api/evaluations", evaluation).then(res => res.data);

// Update evaluation
export const updateEvaluation = (id, evaluation) => api.put(`/api/evaluations/${id}`, evaluation).then(res => res.data);

// Delete evaluation
export const deleteEvaluation = (id) => api.delete(`/api/evaluations/${id}`).then(res => res.data);
