import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar";

import InternDetails from "./pages/InternDetails";
import ProjectDetails from "./pages/ProjectDetails";
import EvaluationCriteria from "./pages/EvaluationCriteria";

export default function App() {
  return (
    <>
      <Navbar />
      <div className="page-container">
        <Routes>
          <Route path="/" element={<InternDetails />} />
          <Route path="/projects" element={<ProjectDetails />} />
          <Route path="/evaluation" element={<EvaluationCriteria />} />
        </Routes>
      </div>
    </>
  );
}
