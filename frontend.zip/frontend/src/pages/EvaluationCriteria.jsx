import { useState } from "react";
import "../styles/EvaluationCriteria.css";
import { getEvaluations } from "../api/api";   // ✅ FIXED
import Loader from "../components/Loader";
import ErrorMessage from "../components/ErrorMessage";

function EvaluationCriteria() {
  const [form, setForm] = useState({
    min_score: "",
    max_score: "",
    evaluator: "",
    start_date: "",
    end_date: "",
    domain: "",
    technology: "",
  });

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSearch = async () => {
    setLoading(true);
    setError("");
    setData(null);

    try {
      const result = await getEvaluations();   // ✅ FIXED
      setData(result);
    } catch {
      setError("Failed to fetch evaluations.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <h2>Evaluation Criteria</h2>

      <div className="form-container">
        {Object.keys(form).map((key) => (
          <input
            key={key}
            name={key}
            placeholder={key.replace("_", " ").toUpperCase()}
            value={form[key]}
            onChange={handleChange}
          />
        ))}
        <button onClick={handleSearch}>Search</button>
      </div>

      {loading && <Loader />}
      {error && <ErrorMessage message={error} />}

      {data && data.length > 0 && (
        <table className="table">
          <thead>
            <tr>
              {Object.keys(data[0]).map((k) => (
                <th key={k}>{k}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, i) => (
              <tr key={i}>
                {Object.values(row).map((v, idx) => (
                  <td key={idx}>{v}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default EvaluationCriteria;
