import { useState } from "react";
import "../styles/ProjectDetails.css";
import { getProjectById } from "../api/api";   // ✅ FIXED IMPORT
import Loader from "../components/Loader";
import ErrorMessage from "../components/ErrorMessage";

function ProjectDetails() {
  const [form, setForm] = useState({
    project_id: "",
    title: "",
    domain: "",
    technology: "",
    mentor: "",
  });

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSearch = async () => {
    if (!form.project_id) {
      setError("Please enter Project ID.");
      return;
    }

    setLoading(true);
    setError("");
    setData(null);

    try {
      const result = await getProjectById(form.project_id);  // ✅ FIXED
      setData(result);
    } catch {
      setError("Failed to fetch project details.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <h2>Project Details</h2>

      <div className="form-container">
        {Object.keys(form).map((key) => (
          <input
            key={key}
            name={key}
            placeholder={key.toUpperCase()}
            value={form[key]}
            onChange={handleChange}
          />
        ))}
        <button onClick={handleSearch}>Search</button>
      </div>

      {loading && <Loader />}
      {error && <ErrorMessage message={error} />}

      {data && (
        <div className="result-container">
          <h3>Project Info</h3>
          <p><b>Title:</b> {data.project?.title}</p>
          <p><b>Domain:</b> {data.project?.domain}</p>
          <p><b>Technology:</b> {data.project?.technology}</p>
          <p><b>Mentor:</b> {data.project?.mentor}</p>

          {data.interns?.length > 0 && (
            <>
              <h3>Interns Involved</h3>
              <table className="table">
                <thead>
                  <tr>
                    {Object.keys(data.interns[0]).map((k) => (
                      <th key={k}>{k}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.interns.map((row, i) => (
                    <tr key={i}>
                      {Object.values(row).map((v, idx) => (
                        <td key={idx}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}

          {data.evaluations?.length > 0 && (
            <>
              <h3>Evaluations</h3>
              <table className="table">
                <thead>
                  <tr>
                    {Object.keys(data.evaluations[0]).map((k) => (
                      <th key={k}>{k}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {data.evaluations.map((row, i) => (
                    <tr key={i}>
                      {Object.values(row).map((v, idx) => (
                        <td key={idx}>{v}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
            </>
          )}
        </div>
      )}
    </div>
  );
}

export default ProjectDetails;
