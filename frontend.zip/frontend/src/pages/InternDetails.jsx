import { useState } from "react";
import "../styles/InternDetails.css";
import { getInternById } from "/src/api/api.js";
import Loader from "../components/Loader";
import ErrorMessage from "../components/ErrorMessage";

function InternDetails() {
  const [form, setForm] = useState({
    intern_id: "",
    name: "",
    email: "",
    degree: "",
    university: "",
    graduation_year: "",
  });

  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const handleChange = (e) =>
    setForm({ ...form, [e.target.name]: e.target.value });

  const handleSearch = async () => {
    if (!form.intern_id) {
      setError("Please enter Intern ID.");
      return;
    }

    setLoading(true);
    setError("");
    setData(null);

    try {
      // ONLY fetch using intern_id
      const result = await getInternById(form.intern_id);

      // API already returns data — no need for result.data
      setData([result]); 
    } catch (err) {
      setError("Failed to fetch intern details.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="page-container">
      <h2>Intern Details</h2>

      <div className="form-container">
        {Object.keys(form).map((key) => (
          <input
            key={key}
            name={key}
            placeholder={key.replace("_", " ").toUpperCase()}
            value={form[key]}
            onChange={handleChange}
          />
        ))}
        <button onClick={handleSearch}>Search</button>
      </div>

      {loading && <Loader />}
      {error && <ErrorMessage message={error} />}

      {data && (
        <table className="table">
          <thead>
            <tr>
              {Object.keys(data[0]).map((k) => (
                <th key={k}>{k}</th>
              ))}
            </tr>
          </thead>
          <tbody>
            {data.map((row, i) => (
              <tr key={i}>
                {Object.values(row).map((v, idx) => (
                  <td key={idx}>{v}</td>
                ))}
              </tr>
            ))}
          </tbody>
        </table>
      )}
    </div>
  );
}

export default InternDetails;
