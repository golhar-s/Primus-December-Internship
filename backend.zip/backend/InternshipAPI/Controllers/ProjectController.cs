using InternshipAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InternshipAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProjectController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ProjectController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/project/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetProjectDetails(int id)
        {
            var project = await _context.Projects
                .Include(p => p.Owner)
                .Include(p => p.Evaluations)
                .FirstOrDefaultAsync(p => p.ProjectId == id);

            if (project == null)
                return NotFound(new { message = "Project not found" });

            return Ok(project);
        }
    }
}
