using InternshipAPI.Data;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InternshipAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class EvaluationController : ControllerBase
    {
        private readonly AppDbContext _context;

        public EvaluationController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/evaluation/filter
        [HttpGet("filter")]
        public async Task<IActionResult> FilterEvaluations(
            int? score,
            string? evaluator,
            DateTime? startDate,
            DateTime? endDate,
            string? projectTitle)
        {
            var query = _context.Evaluations
                .Include(e => e.Intern)
                .Include(e => e.Project)
                .AsQueryable();

            if (score.HasValue)
                query = query.Where(e => e.Score == score);

            if (!string.IsNullOrEmpty(evaluator))
                query = query.Where(e => e.Evaluator.ToLower().Contains(evaluator.ToLower()));

            if (startDate.HasValue)
                query = query.Where(e => e.Project.StartDate >= startDate);

            if (endDate.HasValue)
                query = query.Where(e => e.Project.EndDate <= endDate);

            if (!string.IsNullOrEmpty(projectTitle))
                query = query.Where(e => e.Project.Title.ToLower().Contains(projectTitle.ToLower()));

            return Ok(await query.ToListAsync());
        }
    }
}
