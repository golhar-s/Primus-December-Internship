using InternshipAPI.Data;
using InternshipAPI.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace InternshipAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class InternController : ControllerBase
    {
        private readonly AppDbContext _context;

        public InternController(AppDbContext context)
        {
            _context = context;
        }

        // GET: api/intern/5
        [HttpGet("{id}")]
        public async Task<IActionResult> GetInternDetails(int id)
        {
            var intern = await _context.Interns
                .Include(i => i.Projects)
                .Include(i => i.Evaluations)
                .FirstOrDefaultAsync(i => i.Intern_Id == id);

            if (intern == null)
                return NotFound(new { message = "Intern not found" });

            return Ok(intern);
        }
    }
}
