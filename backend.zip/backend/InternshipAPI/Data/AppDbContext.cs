using Microsoft.EntityFrameworkCore;
using InternshipAPI.Models;

namespace InternshipAPI.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options)
            : base(options)
        { }

        public DbSet<Intern> Interns { get; set; }
        public DbSet<Project> Projects { get; set; }
        public DbSet<Evaluation> Evaluations { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            // Intern table
            modelBuilder.Entity<Intern>(entity =>
            {
                entity.ToTable("interns");
                entity.HasKey(e => e.Intern_Id);
                entity.Property(e => e.Intern_Id).HasColumnName("Intern_Id");
                entity.Property(e => e.FirstName).HasColumnName("FirstName");
                entity.Property(e => e.LastName).HasColumnName("LastName");
                entity.Property(e => e.Email).HasColumnName("Email");
                entity.Property(e => e.Phone).HasColumnName("Phone");
                entity.Property(e => e.Degree).HasColumnName("Degree");
                entity.Property(e => e.University).HasColumnName("University");
                entity.Property(e => e.Year_Graduation).HasColumnName("Year_Graduation");
            });

            // Project table
            modelBuilder.Entity<Project>(entity =>
            {
                entity.ToTable("projects");
                entity.HasKey(e => e.ProjectId);
                entity.Property(e => e.ProjectId).HasColumnName("Project_Id");
                entity.Property(e => e.Title).HasColumnName("Title");
                entity.Property(e => e.Description).HasColumnName("Description");
                entity.Property(e => e.TechStack).HasColumnName("Tech_Stack");
                entity.Property(e => e.StartDate).HasColumnName("Start_Date");
                entity.Property(e => e.EndDate).HasColumnName("End_Date");
                entity.Property(e => e.OwnerId).HasColumnName("Owner_Id");

                entity.HasOne(p => p.Owner)
                      .WithMany(i => i.Projects)
                      .HasForeignKey(p => p.OwnerId)
                      .OnDelete(DeleteBehavior.SetNull);

                entity.Navigation(p => p.Owner).IsRequired(false);
            });

            // Evaluation table
            modelBuilder.Entity<Evaluation>(entity =>
            {
                entity.ToTable("evaluations");
                entity.HasKey(e => e.Evaluation_Id);
                entity.Property(e => e.Evaluation_Id).HasColumnName("Evaluation_Id");
                entity.Property(e => e.Intern_Id).HasColumnName("Intern_Id");
                entity.Property(e => e.Project_Id).HasColumnName("Project_Id");
                entity.Property(e => e.Score).HasColumnName("Score");
                entity.Property(e => e.Feedback).HasColumnName("Feedback");
                entity.Property(e => e.Evaluator).HasColumnName("Evaluator");

                entity.HasOne(e => e.Intern)
                      .WithMany(i => i.Evaluations)
                      .HasForeignKey(e => e.Intern_Id)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.HasOne(e => e.Project)
                      .WithMany(p => p.Evaluations)
                      .HasForeignKey(e => e.Project_Id)
                      .OnDelete(DeleteBehavior.Cascade);

                entity.Navigation(e => e.Intern).IsRequired(false);
                entity.Navigation(e => e.Project).IsRequired(false);
            });
        }
    }
}
