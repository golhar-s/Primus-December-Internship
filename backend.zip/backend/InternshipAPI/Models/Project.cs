using System.ComponentModel.DataAnnotations.Schema;

namespace InternshipAPI.Models
{
    public class Project
    {
        [Column("project_id")]
        public int ProjectId { get; set; }

        [Column("title")]
        public string Title { get; set; }

        [Column("description")]
        public string Description { get; set; }

        [Column("tech_stack")]
        public string TechStack { get; set; }

        [Column("start_date")]
        public DateTime StartDate { get; set; }

        [Column("end_date")]
        public DateTime EndDate { get; set; }

        [Column("owner_id")]
        public int OwnerId { get; set; }
        
        public Intern Owner { get; set; }
        public ICollection<Evaluation> Evaluations { get; set; }

    }
}
