using System.ComponentModel.DataAnnotations.Schema;

namespace InternshipAPI.Models
{
    public class Intern
    {
        [Column("intern_id")]
        public int Intern_Id { get; set; }

        [Column("first_name")]
        public string FirstName { get; set; }

        [Column("last_name")]
        public string LastName { get; set; }

        [Column("email")]
        public string Email { get; set; }

        [Column("phone")]
        public string Phone { get; set; }

        [Column("degree")]
        public string Degree { get; set; }

        [Column("university")]
        public string University { get; set; }

        [Column("year_graduation")]
        public int Year_Graduation { get; set; }

        public ICollection<Project> Projects { get; set; }
        public ICollection<Evaluation> Evaluations { get; set; }
    }
}
