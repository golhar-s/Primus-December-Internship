using System.ComponentModel.DataAnnotations.Schema;

namespace InternshipAPI.Models
{
    public class Evaluation
    {
        [Column("evaluation_id")]
        public int Evaluation_Id { get; set; }

        [Column("intern_id")]
        public int Intern_Id { get; set; }

        [Column("project_id")]
        public int Project_Id { get; set; }

        [Column("score")]
        public decimal Score { get; set; }

        [Column("feedback")]
        public string Feedback { get; set; }

        [Column("evaluator")]
        public string Evaluator { get; set; }

        public Intern Intern { get; set; }
        public Project Project { get; set; }
    }
}
